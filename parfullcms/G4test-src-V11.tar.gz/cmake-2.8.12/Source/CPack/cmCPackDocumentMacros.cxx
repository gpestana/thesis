#include "cmCPackDocumentMacros.h"

void cmCPackDocumentMacros::GetMacrosDocumentation(
        std::vector<cmDocumentationEntry>& )
{
   // Commented-out example of use
   //
   //    cmDocumentationEntry e("cpack_<macro>",
   //            "Brief Description"
   //            "which may be on several lines.",
   //            "Long description in pre-formatted format"
   //            "                          blah\n"
   //            "                          blah\n"
   //);
   //v.push_back(e);
}
